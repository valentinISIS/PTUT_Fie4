import os
import soundfile as sf
import torch
import pandas as pd
from transformers import WhisperProcessor, WhisperForConditionalGeneration
from jiwer import wer
from pydub import AudioSegment
import time  # Pour mesurer le temps d'exécution

# Chemins des fichiers
AUDIO_FOLDER = "converted_clips"  # Remplacez par le chemin vers votre dossier clips
TSV_FILE = "cv-corpus-20.0-delta-2024-12-06/fr/validated.tsv"  # Remplacez par le chemin vers le fichier TSV

# Charger les métadonnées du jeu de données
data = pd.read_csv(TSV_FILE, sep="\t")

# Charger le modèle Whisper et le processeur
processor = WhisperProcessor.from_pretrained("openai/whisper-large-v3")
model = WhisperForConditionalGeneration.from_pretrained("openai/whisper-large-v3")
model.eval()


def convert_audio_files(input_folder, output_folder):
    """
    Convertit tous les fichiers MP3 d'un dossier en WAV 16 kHz pour Whisper.

    :param input_folder: Dossier contenant les fichiers MP3.
    :param output_folder: Dossier où enregistrer les fichiers convertis.
    """
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    for file_name in os.listdir(input_folder):
        if file_name.endswith(".mp3"):
            input_path = os.path.join(input_folder, file_name)
            output_path = os.path.join(output_folder, os.path.splitext(file_name)[0] + ".wav")

            # Charger l'audio et convertir en 16 kHz, mono
            audio = AudioSegment.from_mp3(input_path)
            audio = audio.set_frame_rate(16000).set_channels(1)

            # Exporter en WAV
            audio.export(output_path, format="wav")
            print(f"Converti : {file_name} -> {output_path}")


# Fonction pour transcrire un fichier audio avec Whisper et calculer le RTF
def transcribe_audio(file_path):
    try:
        # Charger le fichier audio avec soundfile
        audio_input, samplerate = sf.read(file_path)
        audio_duration = len(audio_input) / samplerate  # Durée de l'audio en secondes

        # Vérifier et convertir en 16 kHz si nécessaire
        if samplerate != 16000:
            raise ValueError("Le modèle Whisper nécessite un audio échantillonné à 16 kHz.")

        # Prétraiter l'audio pour Whisper
        inputs = processor(audio_input, return_tensors="pt", sampling_rate=16000)

        # Mesurer le temps de traitement
        start_time = time.time()

        # Générer la transcription
        with torch.no_grad():
            predicted_ids = model.generate(inputs.input_features)
            transcription = processor.batch_decode(predicted_ids, skip_special_tokens=True, language="fr")[0]

        # Calculer le temps de traitement
        processing_time = time.time() - start_time

        # Calculer le RTF
        rtf = processing_time / audio_duration

        return transcription, rtf
    except Exception as e:
        print(f"Erreur lors de la transcription de {file_path}: {e}")
        return None, None


# Tester tous les fichiers audio et calculer le WER et RTF
results = []
for index, row in data.iterrows():
    audio_path = os.path.join(AUDIO_FOLDER, row["path"].split(".mp3")[0] + ".wav")
    reference_text = row["sentence"]

    # Vérifier si le fichier existe
    if not os.path.exists(audio_path):
        print(f"Fichier manquant : {audio_path}")
        continue

    # Transcrire l'audio avec Whisper
    transcription, rtf = transcribe_audio(audio_path)

    if transcription is not None:
        # Calculer le WER
        error_rate = wer(reference_text, transcription)
        results.append({
            "audio_path": audio_path,
            "reference": reference_text,
            "transcription": transcription,
            "wer": error_rate,
            "rtf": rtf  # Ajouter le RTF aux résultats
        })
        print(f"Fichier : {audio_path} | WER : {error_rate:.2%} | RTF : {rtf:.4f}")
    else:
        print(f"Échec de la transcription pour {audio_path}")

# Sauvegarder les résultats dans un fichier CSV
results_df = pd.DataFrame(results)
results_df.to_csv("whisper_test_results.csv", index=False)
print("Résultats sauvegardés dans whisper_test_results.csv")