import os
import soundfile as sf
import torch
from transformers import Wav2Vec2Processor, Wav2Vec2ForCTC
from jiwer import wer
import numpy as np
import time  # Pour mesurer le temps d'exécution

# Chemins des fichiers
AUDIO_FOLDER = "cv-corpus-20.0-delta-2024-12-06/fr/clips"  # Remplacez par le chemin vers votre dossier clips
TSV_FILE = "cv-corpus-20.0-delta-2024-12-06/fr/validated.tsv"  # Remplacez par le chemin vers le fichier TSV

# Charger les métadonnées du jeu de données
import pandas as pd
data = pd.read_csv(TSV_FILE, sep="\t")

# Charger le modèle Mistral (Mistral est disponible dans Hugging Face)
processor = Wav2Vec2Processor.from_pretrained("facebook/wav2vec2-large-xlsr-53-french")
model = Wav2Vec2ForCTC.from_pretrained("facebook/wav2vec2-large-xlsr-53-french")

# Fonction pour transcrire un fichier audio et calculer le RTF
def transcribe_audio(file_path):
    try:
        # Charger le fichier audio avec soundfile
        audio_input, samplerate = sf.read(file_path)
        audio_duration = len(audio_input) / samplerate  # Durée de l'audio en secondes

        # Prétraiter l'audio pour le modèle
        inputs = processor(audio_input, return_tensors="pt", sampling_rate=16000)

        # Mesurer le temps de traitement
        start_time = time.time()

        # Transcrire l'audio avec le modèle Mistral
        with torch.no_grad():
            logits = model(input_values=inputs.input_values).logits
            predicted_ids = torch.argmax(logits, dim=-1)

        # Calculer le temps de traitement
        processing_time = time.time() - start_time

        # Calculer le RTF
        rtf = processing_time / audio_duration

        # Décoder les IDs en texte
        transcription = processor.decode(predicted_ids[0])
        return transcription, rtf
    except Exception as e:
        print(f"Erreur lors de la transcription de {file_path}: {e}")
        return None, None

# Tester tous les fichiers audio et calculer le WER et RTF
results = []
for index, row in data.iterrows():
    audio_path = os.path.join(AUDIO_FOLDER, row["path"])
    reference_text = row["sentence"]

    # Vérifier si le fichier existe
    if not os.path.exists(audio_path):
        print(f"Fichier manquant : {audio_path}")
        continue

    # Transcrire l'audio avec Mistral
    transcription, rtf = transcribe_audio(audio_path)

    if transcription is not None:
        # Calculer le WER
        error_rate = wer(reference_text, transcription)
        results.append({
            "audio_path": audio_path,
            "reference": reference_text,
            "transcription": transcription,
            "wer": error_rate,
            "rtf": rtf  # Ajouter le RTF aux résultats
        })
        print(f"Fichier : {audio_path} | WER : {error_rate:.2%} | RTF : {rtf:.4f}")
    else:
        print(f"Échec de la transcription pour {audio_path}")

# Sauvegarder les résultats dans un fichier CSV
results_df = pd.DataFrame(results)
results_df.to_csv("wav2vec2_test_results.csv", index=False)
print("Résultats sauvegardés dans wav2vec2_test_results.csv")